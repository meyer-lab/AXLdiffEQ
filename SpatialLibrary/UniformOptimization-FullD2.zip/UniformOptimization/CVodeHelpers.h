//
//  CVodeHelpers.h
//  UniformOptimization
//
//  Created by Aaron Meyer on 10/8/13.
//  Copyright (c) 2013 Aaron Meyer. All rights reserved.
//

#ifndef __UniformOptimization__CVodeHelpers__
#define __UniformOptimization__CVodeHelpers__

#include <iostream>
#include <cvode/cvode.h>             /* prototypes for CVODE fcts., consts. */
#include <cvode/cvode_dense.h>       /* prototype for CVDense */
#include <sundials/sundials_dense.h> /* definitions DlsMat DENSE_ELEM */
#include <sundials/sundials_types.h> /* definition of type realtype */


#define print_CV_err 1
#define rel_tol 1E-6
#define abs_tol 1E-6

int solver_setup (void **, N_Vector , void *, N_Vector , CVRhsFn);
int check_flag(void *, char *, int );
void errorHandler (int, const char *, const char *, char *, void *);

#endif /* defined(__UniformOptimization__CVodeHelpers__) */
