//
//  BlasHeader.h
//  FiniteDiffGSL
//
//  Created by Aaron Meyer on 7/6/13.
//  Copyright (c) 2013 Aaron Meyer. All rights reserved.
//

//AXL 1, AXLgas1 2, AXLgas2 3, AXLgas12 4, AXLdimer1 5, AXLdimer2 6, AXLud 7, Gas 8;


#ifndef BLAS_HEADER
#define BLAS_HEADER

#include "HelperFunctions.h"

using namespace std;

struct queT {
    struct rates In;
    double *out;
};

extern "C" int matlabEntry(double * , double * , int);
extern "C" int calcProfileMatlab(double *, double *, double *, int, double, double, double);
extern "C" int matlabDiffTPS(double *, double , double *, int , double , double *, double *, int, double *);
extern "C" int matlabDiffTPS_pY(double *, double , double *, int , double , double *, double *, int, double *);
extern "C" int matlabDiffTPS_pYavg(double *, double, double *, int, double , double *, double *, int, double *);
//extern "C" int matlabFluxify(double *, double *, double *);
extern "C" void rEntry(double *, const double *);

#endif