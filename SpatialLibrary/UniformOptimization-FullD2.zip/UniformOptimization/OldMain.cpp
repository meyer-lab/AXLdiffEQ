//
//  OldMain.cpp
//  UniformOptimization
//
//  Created by Aaron Meyer on 11/1/13.
//  Copyright (c) 2013 Aaron Meyer. All rights reserved.
//

#include "OldMain.h"


//void runSA (vector<double> *xBest, double *eBest, double temperature, double seed, int kMax) {
//    vector<double> minn = {1E-5,1E-5,1E-5,1E-5,1E-5,1E-5,1E-5,1E-5,1E-5,1E-5,1E-9,1E-9,1E-9,1E-9,1E-9,1E-9};
//    vector<double> maxx = {1E5,1E5,1E5,1E5,1E5,1E5,1E5,1E5,1E5,1E5,1E5,1E-9,1E2,1E2,1E2,1E2};
//    vector<double> x;
//
//    size_t mvIDX;
//    vector<double> xNew;
//    vector<double> xNot;
//    xNot.assign(xBest->begin(),xBest->end());
//
//    double eNew = 10000;
//    double e = calcErrorOpt(xNot);
//    *eBest = calcErrorOpt(xNot);
//
//    default_random_engine generator;
//    generator.seed(seed);
//    normal_distribution<double> rndValue(0,1);
//    uniform_int_distribution<size_t> mvRND(0,xNot.size()-1);
//    uniform_real_distribution<double> uniRnd(0,1);
//
//    xNew.assign(xNot.begin(),xNot.end());
//    x.assign(xNot.begin(),xNot.end());
//
//    for (int k = 0; k < kMax; k++) {
//        mvIDX = mvRND(generator);
//        xNew[mvIDX] = pow(10,(log10(xNew[mvIDX]) + rndValue(generator)*temperature));
//
//        if (xNew[mvIDX] < minn[mvIDX]) {
//            xNew[mvIDX] = minn[mvIDX];
//        } else if (xNew[mvIDX] > maxx[mvIDX]) {
//            xNew[mvIDX] = maxx[mvIDX];
//        }
//
//        eNew = calcErrorOpt(xNew);
//
//        if (prob(eNew, e, temperature) > uniRnd(generator)) {
//            x.assign(xNew.begin(),xNew.end());
//            e = eNew;
//        } else {
//            xNew.assign(x.begin(),x.end());
//        }
//
//        if (e < *eBest) {
//            xBest->assign(x.begin(),x.end());
//            *eBest = e;
//        }
//
//    }
//}

/* This runs a "traditional" simulated annealeaing algorithm, and outputs the current position, not the best. */
//void runSAcur (vector<double> *xBest, double *eBest, double temperature, double varDist, double seed, int kMax) {
//    vector<double> minn = {1E-5,1E-5,1E-5,1E-5,1E-5,1E-5,1E-5,1E-5,1E-5,1E-5,1E-9,1E-9,1E-9,1E-9,1E-9,1E-9};
//    vector<double> maxx = {1E5,1E5,1E5,1E5,1E5,1E5,1E5,1E5,1E5,1E5,1E5,1E-9,1E2,1E2,1E2,1E2};
//    vector<double> x;
//
//    size_t mvIDX;
//    vector<double> xNew;
//    vector<double> xNot;
//    xNot.assign(xBest->begin(),xBest->end());
//
//    double eNew = 10000;
//    double e = calcErrorOpt(xNot);
//    *eBest = calcErrorOpt(xNot);
//
//    default_random_engine generator;
//    generator.seed(seed);
//    normal_distribution<double> rndValue(0,1);
//    uniform_int_distribution<size_t> mvRND(0,xNot.size()-1);
//    uniform_real_distribution<double> uniRnd(0,1);
//
//    xNew.assign(xNot.begin(),xNot.end());
//    x.assign(xNot.begin(),xNot.end());
//
//    for (int k = 0; k < kMax; k++) {
//        mvIDX = mvRND(generator);
//        xNew[mvIDX] = pow(10,(log10(xNew[mvIDX]) + rndValue(generator)*varDist));
//
//        if (xNew[mvIDX] < minn[mvIDX]) {
//            xNew[mvIDX] = minn[mvIDX];
//        } else if (xNew[mvIDX] > maxx[mvIDX]) {
//            xNew[mvIDX] = maxx[mvIDX];
//        }
//
//        eNew = calcErrorOpt(xNew);
//
//        if (prob(eNew, e, temperature) > uniRnd(generator)) {
//            x.assign(xNew.begin(),xNew.end());
//            e = eNew;
//        } else {
//            xNew.assign(x.begin(),x.end());
//        }
//    }
//
//    xBest->assign(x.begin(),x.end());
//    *eBest = e;
//}


//void oldMain () {
//    const int nThreads = 7;
//    double eBest = 1000;
//
//    vector<double> xNot = {          33.8246016046833,
//        0.305891222845804,
//        1.00001063285198e-05,
//        0.477949729084496,
//        5.77715615342783,
//        0.000415408779752554,
//        0.00510905244546573,
//        0.00209393477002513,
//        1.26830777310632e-09,
//        7.44478489335694e-05,
//        3.7344800295714e-05,
//        0.154320107293071};
//
//
//    vector<double> xs[nThreads];
//    double errs[nThreads];
//
//
//    cout << "Starting error: " << calcErrorOpt(xNot) << endl;
//
//    std::thread t[nThreads];
//
//    for (int ii = 0; ii < nThreads; ii++) {
//        xs[ii].assign(xNot.begin(),xNot.end());
//        errs[ii] = eBest;
//    }
//
//    for (int ii = 0; ii < nThreads; ii++) {
//        t[ii] = std::thread(runSA,&xs[ii],&errs[ii],1.0, random(),10);
//    }
//
//
//
//    for (int jj = 1; jj < 5; jj++) {
//        cout << "T: " << 1.0/(1 + log((double) jj)) << endl;
//
//        for (int ii = 0; ii < nThreads; ii++) {
//            t[ii].join();
//
//            if (eBest > errs[ii]) {
//                eBest = errs[ii];
//                xNot.assign(xs[ii].begin(),xs[ii].end());
//
//                cout << endl << endl << endl << "Err: " << eBest << endl;
//
//                for (size_t kk = 0; kk < xNot.size(); kk++) {
//                    cout << xNot[kk] << ", ";
//                }
//
//                cout << endl << endl;
//            } else {
//                errs[ii] = eBest;
//                xs[ii].assign(xNot.begin(), xNot.end());
//            }
//
//            t[ii] = std::thread(runSA,&xs[ii],&errs[ii],5.0/(1 + log((double) jj)), random(),100);
//
//        }
//    }
//
//    for (int ii = 0; ii < nThreads; ii++) t[ii].join();
//}



//void sensAnalysis () {
//    const int nThreads = 7;
//    double eBest = 1000;
//    double nSteps = 100;
//
//    vector<double> xNot = {6916.48607972976,0.915450762480475,1.79961195488823e-05,1.00145583950968e-05,1.97696506630222,0.00229167385574664,0.0076705362102835,
//        0.00409049011682068,0.0892447805414769,1e-09,1.0136989496025e-09,0.0495887753636237,0.0347470752191313,0.0100197785350122};
//
//
//    vector<double> xs[nThreads];
//    double errs[nThreads];
//
//
//    cout << "Starting error: " << calcErrorOpt(xNot) << endl;
//
//    std::thread t[nThreads];
//
//    for (int ii = 0; ii < nThreads; ii++) {
//        xs[ii].assign(xNot.begin(),xNot.end());
//        errs[ii] = eBest;
//    }
//
//    for (int ii = 0; ii < nThreads; ii++) {
//        t[ii] = std::thread(runSAcur,&xs[ii],&errs[ii],30, 1.0, random(),nSteps);
//    }
//
//    for (size_t jj = 1; jj < 500; jj++) {
//
//        for (size_t ii = 0; ii < nThreads; ii++) {
//            t[ii].join();
//
//            for (size_t kk = 0; kk < xNot.size(); kk++) {
//                cout << xs[ii][kk] << ", ";
//            }
//            cout << errs[ii] << endl;
//
//
//            if (eBest > errs[ii]) {
//                eBest = errs[ii];
//                xNot.assign(xs[ii].begin(),xs[ii].end());
//            } else {
//                errs[ii] = eBest;
//                xs[ii].assign(xNot.begin(), xNot.end());
//            }
//
//            t[ii] = std::thread(runSAcur,&xs[ii],&errs[ii],30, 1.0, random(),nSteps);
//
//        }
//    }
//
//    for (int ii = 0; ii < nThreads; ii++) t[ii].join();
//}


double prob(double eNew, double eOld, double temp) {
    if (eNew < eOld) {
        return 1;
    } else {
        return exp(-(eNew - eOld) / temp);
    }
}


//cout << "Error: " << calcError(Param(paramm)) << endl;


//    double tps[] = {10};
//    double D[7] = {0, 1, 1, 1, 1, 1, 1};
//
//    double GasIn[100];
//    int gridIn = NELEMS(GasIn);
//    double dataPtrs[NELEMS(tps)];
//
//    double sigma = 0.1;
//    double maxx = 1;
//    double summ = 0;
//
//    for (int ii = 0; ii < gridIn; ii++) {
//        double x = ((double) ii) / ((double) gridIn);
//
//        GasIn[ii] = cos(sigma*x) + 1;
//        summ += GasIn[ii];
//    }
//
//    for (int ii = 0; ii < gridIn; ii++) {
//        GasIn[ii] = GasIn[ii] / summ * maxx * gridIn;
//        cout << GasIn[ii] << endl;
//    }
//
//    matlabDiffTPS_pYavg(dataPtrs, 1000.0, GasIn, NELEMS(GasIn), 0.01, params, tps, NELEMS(tps), D);
//
//    for (int ii = 0; ii < NELEMS(dataPtrs); ii++ ) {
//        cout << dataPtrs[ii] << endl;
//    }
