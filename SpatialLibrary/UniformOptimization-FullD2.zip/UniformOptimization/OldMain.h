//
//  OldMain.h
//  UniformOptimization
//
//  Created by Aaron Meyer on 11/1/13.
//  Copyright (c) 2013 Aaron Meyer. All rights reserved.
//

#ifndef __UniformOptimization__OldMain__
#define __UniformOptimization__OldMain__

#include <iostream>

#endif /* defined(__UniformOptimization__OldMain__) */
