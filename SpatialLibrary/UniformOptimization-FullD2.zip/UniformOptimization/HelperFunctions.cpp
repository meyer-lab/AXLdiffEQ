//
//  HelperFunctions.cpp
//  UniformOptimization
//
//  Created by Aaron Meyer on 10/3/13.
//  Copyright (c) 2013 Aaron Meyer. All rights reserved.
//

#include "HelperFunctions.h"
#include <nvector/nvector_serial.h>  /* serial N_Vector types, fcts., macros */
#include "CVodeHelpers.h"
#include <sundials/sundials_dense.h> /* definitions DlsMat DENSE_ELEM */
#include <sundials/sundials_math.h>
#include <cvode/cvode_impl.h>
#include <cmath>
#include <fstream>


double diffD[Nspecies];


#define dR1 (r->Binding1 * x_d[1] * x_d[0] - r->Unbinding1 * x_d[2])
#define dR2 (r->Binding2 * x_d[1] * x_d[0] - r->Unbinding2 * x_d[3])
#define dR3 (r->Binding2 * x_d[2] * x_d[0] - r->Unbinding2 * x_d[4])
#define dR4 (r->Binding1 * x_d[3] * x_d[0] - r->Unbinding1 * x_d[4])
#define dR5 (r->xFwd1 * x_d[1] * x_d[2] - r->xRev1 * x_d[5])
#define dR6 (r->xFwd2 * x_d[1] * x_d[3] - r->xRev2 * x_d[5])
#define Rxn3 (r->xFwd3*x_d[2]*x_d[2] - r->xRev3*x_d[6])
#define Rxn6 (r->xFwd6*x_d[3]*x_d[3] - r->xRev6*x_d[7])
#define Rxn7 (r->xFwd7*x_d[4]*x_d[1] - r->xRev7*x_d[6])
#define Rxn8 (r->xFwd8*x_d[4]*x_d[1] - r->xRev8*x_d[7])
#define Rxn9 (r->xFwd9*x_d[5]*x_d[0] - r->xRev9*x_d[6])
#define Rxn10 (r->xFwd10*x_d[5]*x_d[0] - r->xRev10*x_d[7])
#define Rxn11 (r->xFwd11*x_d[6] - r->xRev11*x_d[8])
#define Rxn12 (r->xFwd12*x_d[7] - r->xRev12*x_d[8])

ratesFull ratesFill (rates in) {
    ratesFull out;
    
    out.Binding1 = in.Binding1;
    out.Binding2 = in.Binding2;
    out.Unbinding1 = in.Unbinding1;
    out.Unbinding2 = in.Unbinding2;
    out.xFwd1 = in.xFwd1;
    out.xRev1 = in.xRev1;
    out.xFwd3 = in.xFwd3;
    out.xRev3 = in.xRev3;
    out.xFwd6 = in.xFwd6;
    out.xRev6 = in.xRev6;
    out.xFwd11 = in.xFwd11;
    out.xRev11 = in.xRev11;
    out.scaleA = in.scaleA;
    out.scaleAG1 = in.scaleAG1;
    out.scaleAG2 = in.scaleAG2;
    out.scaleAG12 = in.scaleAG12;
    out.scaleD1 = in.scaleD1;
    out.scaleD1g1 = in.scaleD1g1;
    out.scaleD1g2 = in.scaleD1g2;
    out.autocrine[0] = in.autocrine[0];
    out.autocrine[1] = in.autocrine[1];
    out.autocrine[2] = in.autocrine[2];
    out.autocrine[3] = in.autocrine[3];
    out.xFwd2 = in.xFwd1*in.Binding1/in.Binding2;
    out.xRev2 = in.xRev1*in.Unbinding1/in.Unbinding2;
    out.xFwd7 = in.xFwd3*in.Binding1/in.Binding2;
    out.xRev7 = in.xRev3*in.Unbinding1/in.Unbinding2;
    out.xFwd8 = in.xFwd6*in.Binding2/in.Binding1;
    out.xRev8 = in.xRev6*in.Unbinding2/in.Unbinding1;
    out.xFwd9 = in.xFwd3*in.Binding1/in.xFwd1;
    out.xRev9 = in.xRev3*in.Unbinding1/in.xRev1;
    out.xFwd10 = in.xFwd6*in.Binding2*in.Binding2/in.xFwd1/in.Binding1;
    out.xRev10 = in.xRev6*in.Unbinding2*in.Unbinding2/in.xRev1/in.Unbinding1;
    out.xFwd12 = in.xFwd3*in.xFwd11*in.Binding1*in.Binding1/in.xFwd6/in.Binding2/in.Binding2;
    out.xRev12 = in.xRev3*in.xRev11*in.Unbinding1*in.Unbinding1/in.xRev6/in.Unbinding2/in.Unbinding2;
    
    return out;
}

// Need to check this
double pYcalc (N_Vector state, struct rates p) {
    
    cout << Ith(state,1)*p.scaleA << " " << Ith(state,2)*p.scaleAG1 << " " << Ith(state,3)*p.scaleAG2 << " " << Ith(state,4)*p.scaleAG12 << " " << Ith(state,5)*p.scaleD1 << " " << Ith(state,6)*p.scaleD1g1 << " " << Ith(state,7)*p.scaleD1g2 << " " << Ith(state,8) << endl;
    
    return (Ith(state,1)*p.scaleA + Ith(state,2)*p.scaleAG1 + Ith(state,3)*p.scaleAG2 + Ith(state,4)*p.scaleAG12 + Ith(state,5)*p.scaleD1 + Ith(state,6)*p.scaleD1g1 + Ith(state,7)*p.scaleD1g2 + Ith(state,8))/(Ith(state,1) + Ith(state,2) + Ith(state,3) + Ith(state,4) + 2*(Ith(state,5) + Ith(state,6) + Ith(state,7) + Ith(state,8)));
}

inline int AXL_react(realtype t, N_Vector x , N_Vector dxdt,void *user_data) {
    struct ratesFull *r = (struct ratesFull *) user_data;
    realtype* x_d = NV_DATA_S(x);
    realtype* dxdt_d = NV_DATA_S(dxdt);
    
    dxdt_d[0] = 0;
    dxdt_d[1] = - dR6 - dR5 - dR1 - dR2 - Rxn7 - Rxn8; // AXL
    dxdt_d[2] = - dR5 + dR1 - dR3 - 2*Rxn3; // AXLgas1
    dxdt_d[3] = - dR6 + dR2 - dR4 - 2*Rxn6; // AXLgas2
    dxdt_d[4] = dR3 + dR4 - Rxn7 - Rxn8; // AXLgas12
    dxdt_d[5] = dR6 + dR5 - Rxn9 - Rxn10; // AXLdimer1
    dxdt_d[6] = Rxn3 - Rxn11 + Rxn7 + Rxn9; // AXLdimer1gas1
    dxdt_d[7] = Rxn6 - Rxn12 + Rxn8 + Rxn10; // AXLdimer1gas2
    dxdt_d[8] = Rxn11 + Rxn12; // AXLdimer2
    
    return 0;
}


struct rates Param( param_type params) {
    struct rates out;
    
    out.Binding1 = params[0];
    out.Binding2 = params[1];
    out.Unbinding1 = params[2];
    out.Unbinding2 = params[3];
    out.xFwd1 = params[4];
    out.xRev1 = params[5];
    out.xFwd3 = params[6];
    out.xRev3 = params[7];
    out.xFwd6 = params[8];
    out.xRev6 = params[9];
    out.xFwd11 = params[10];
    out.xRev11 = params[11];
    out.scaleA = params[12];
    out.scaleAG1 = params[13];
    out.scaleAG2 = params[14];
    out.scaleAG12 = params[15];
    out.scaleD1 = params[16];
    out.scaleD1g1 = params[17];
    out.scaleD1g2 = params[18];
    out.autocrine[0] = params[19];
    out.autocrine[1] = params[20];
    out.autocrine[2] = params[21];
    out.autocrine[3] = params[22];
    
    return out;
}

param_type deParam( struct rates params) {
    
param_type out = {    params.Binding1,
    params.Binding2,
    params.Unbinding1,
    params.Unbinding2,
    params.xFwd1,
    params.xRev1,
    params.xFwd3,
    params.xRev3,
    params.xFwd6,
    params.xRev6,
    params.xFwd11,
    params.xRev11,
    params.scaleA,
    params.scaleAG1,
    params.scaleAG2,
    params.scaleAG12,
    params.scaleD1,
    params.scaleD1g1,
    params.scaleD1g2,
    params.autocrine[0],
    params.autocrine[1],
    params.autocrine[2],
    params.autocrine[3]};
    
    return out;
}

// Calculate the initial state by waiting a long time with autocrine Gas
int initState( N_Vector init, struct ratesFull params, double autocrine, double AXL, N_Vector abstol) {
    void *cvode_mem = NULL;
    realtype t;
    
    for (int ii = 0; ii < Nspecies ; ii++) {
        Ith(init,ii) = 0;
    }
    Ith(init,1) = AXL;
    Ith(init,0) = autocrine;
    
    
    int flag = solver_setup (&cvode_mem, init, &params, abstol, SELECTED_MODEL);
    if (flag == 1) {
        cout << "Error at solver setup" << endl;
        return(1);
    }
    
    flag = CVode(cvode_mem, autocrineT, init, &t, CV_NORMAL);
    if (check_flag(&flag, (char*)"CVode Initial Value", 1)) {
        CVodeFree(&cvode_mem);
        return(1);
    }
    
    /* Free integrator memory */
    CVodeFree(&cvode_mem);
    
    return 0;
}

int AXL_react_diff(realtype t, N_Vector xx , N_Vector dxxdt, void *user_data) {
    realtype* xx_d = NV_DATA_S(xx);
    realtype* dxxdt_d = NV_DATA_S(dxxdt);
    double a, b;
    size_t pos, spec;
    size_t grid_size = (size_t) NV_LENGTH_S(xx)/Nspecies;
    double dRdRMaxRMaxR = maxR*maxR*(1.0/grid_size)*(1.0/grid_size);
    
    for (size_t ii = 0; ii < (grid_size-1); ii++) {
        a = (2.0-1.0/ii);
        b = (2.0+1.0/ii);
        
        for (spec = 0; spec < Nspecies; spec++) {
            pos = spec*grid_size + ii;
            dxxdt_d[pos] = (-4.0*xx_d[pos] + a*xx_d[pos - 1] + b*xx_d[pos + 1])/2/dRdRMaxRMaxR;
        }
    }
    
    for (size_t ii = 0; ii < Nspecies; ii++) {
        // Take care of the inner boundary condition
        dxxdt_d[ii*grid_size] = 4*(xx_d[ii*grid_size + 1] - xx_d[ii*grid_size])/dRdRMaxRMaxR;
        
        // Outer boundary condition
        dxxdt_d[(ii+1)*grid_size - 1] = -4*(xx_d[(ii+1)*grid_size - 1] - xx_d[(ii+1)*grid_size - 2])/dRdRMaxRMaxR;
    }
    
    N_Vector reactIn = N_VNew_Serial(Nspecies);
    //if (check_flag((void *)reactIn, (char*)"N_VNew_Serial", 0)) return(1);
    N_Vector reactOut = N_VNew_Serial(Nspecies);
    //if (check_flag((void *)reactOut, (char*)"N_VNew_Serial", 0)) return(1);
    
    // Add in the reaction for each location
    for (size_t jj = 0; jj < grid_size; jj++) {
        
        for (size_t ii = 0; ii < Nspecies; ii++) {
            Ith(reactIn,ii) = xx_d[ii*grid_size + jj];
        }
        
        AXL_react(t, reactIn ,reactOut,user_data);
        
        for (size_t ii = 0; ii < Nspecies; ii++) {
            // Also convert by diffusion coefficient
            dxxdt_d[ii*grid_size + jj] *= diffD[ii];
            
            // Add in reaction difference
            dxxdt_d[ii*grid_size + jj] += Ith(reactOut,ii);
        }
    }
    
    N_VDestroy_Serial(reactIn);
    N_VDestroy_Serial(reactOut);
    
    return 0;
}


void errorPrint(string In) {
    ofstream errfile;
    
    errfile.open ("error.txt", ios::app);
    errfile << In << endl;
    errfile.close();
}


