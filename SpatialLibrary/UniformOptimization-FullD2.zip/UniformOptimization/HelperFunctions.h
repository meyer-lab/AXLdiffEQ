//
//  HelperFunctions.h
//  UniformOptimization
//
//  Created by Aaron Meyer on 10/3/13.
//  Copyright (c) 2013 Aaron Meyer. All rights reserved.
//

#ifndef __UniformOptimization__HelperFunctions__
#define __UniformOptimization__HelperFunctions__

#include <nvector/nvector_serial.h>  /* serial N_Vector types, fcts., macros */
#include <boost/array.hpp>
#include <sundials/sundials_dense.h> /* definitions DlsMat DENSE_ELEM */
#include <cvode/cvode_direct.h>

#define Nspecies 9
#define autocrineT 1000
#define maxR 1.0


using namespace std;


extern double diffD[Nspecies];



#define SELECTED_MODEL AXL_react

#define Ith(v,i)    NV_Ith_S(v,i)       /* Ith numbers components 1..NEQ */
#define NELEMS(x)  (sizeof(x) / sizeof(x[0]))



typedef boost::array< double , 23 > param_type;
typedef boost::array< double , Nspecies > state_type;

struct rates {
    double Binding1;
    double Binding2;
    double Unbinding1;
    double Unbinding2;
    double xFwd1;
    double xRev1;
    double xFwd3;
    double xRev3;
    double xFwd6;
    double xRev6;
    double xFwd11;
    double xRev11;
    double scaleA;
    double scaleAG1;
    double scaleAG2;
    double scaleAG12;
    double scaleD1;
    double scaleD1g1;
    double scaleD1g2;
    double autocrine[4];
};

struct ratesFull {
    double Binding1;
    double Binding2;
    double Unbinding1;
    double Unbinding2;
    double xFwd1;
    double xRev1;
    double xFwd3;
    double xRev3;
    double xFwd6;
    double xRev6;
    double xFwd11;
    double xRev11;
    double scaleA;
    double scaleAG1;
    double scaleAG2;
    double scaleAG12;
    double scaleD1;
    double scaleD1g1;
    double scaleD1g2;
    double autocrine[4];
    double xFwd2;
    double xRev2;
    double xFwd7;
    double xRev7;
    double xFwd8;
    double xRev8;
    double xFwd9;
    double xRev9;
    double xFwd10;
    double xRev10;
    double xFwd12;
    double xRev12;
};




inline int AXL_react(realtype, N_Vector, N_Vector,void *);
param_type deParam( struct rates );
struct rates Param( param_type );
int initState( N_Vector , struct ratesFull , double , double , N_Vector );
double pYcalc (N_Vector, struct rates);
int AXL_react_diff(realtype, N_Vector  , N_Vector , void *);
int AXL_react_Jac(long, realtype, N_Vector, N_Vector, DlsMat, void *, N_Vector, N_Vector, N_Vector);
void fluxify (double *, double *, struct rates *);
ratesFull ratesFill (rates);
void errorPrint(string);



#endif /* defined(__UniformOptimization__HelperFunctions__) */
