//
//  BlasHeader.c
//  FiniteDiffGSL
//
//  Created by Aaron Meyer on 7/13/13.
//  Copyright (c) 2013 Aaron Meyer. All rights reserved.
//

#include <iostream>
#include <thread>
#include <queue>

#include <iostream>
#include <fstream>
#include <atomic>

#include <cvode/cvode.h>             /* prototypes for CVODE fcts., consts. */
#include <nvector/nvector_serial.h>  /* serial N_Vector types, fcts., macros */

#include "BlasHeader.h"
#include "HelperFunctions.h"
#include "CVodeHelpers.h"
#include "Fitting.h"


using namespace std;


extern "C" int matlabEntry(double *dataPtr, double *pIn, int nIn) {
    
    const int nThreads = 8;
    queue<queT> runThese;
    std::thread t[nThreads];
    atomic<bool> done[nThreads];
    queT in;
    
    for (size_t ii = 0; ii < nIn; ii++) {
        param_type pInSlice;
        
        for (size_t jj = 0; jj < pInSlice.size(); jj++) {
            pInSlice[jj] = pIn[(size_t) ii*pInSlice.size() + jj];
        }
        
        in.In = Param(pInSlice);
        in.out = &dataPtr[ii];
        runThese.push(in);
     }

    
    for (int ii = 0; ii < nThreads; ii++) {
        if (runThese.size() == 0) {
            break;
        }
        t[ii] = std::thread(calcErrorRef,runThese.front().In,runThese.front().out, &done[ii]);
        runThese.pop();
    }
    
    while (runThese.size() > 0) {
        for (int ii = 0; ii < nThreads; ii++) {
            if (runThese.size() == 0) {
                break;
            }
            
            if (done[ii] == true) {
                t[ii].join();
                done[ii] = false;
                t[ii] = std::thread(calcErrorRef,runThese.front().In,runThese.front().out, &done[ii]);
                runThese.pop();
            }
        }
    }
    
    if (nIn > nThreads) {
        for (int ii = 0; ii < nThreads; ii++) {
            t[ii].join();
        }
    } else {
        for (int ii = 0; ii < nIn; ii++) {
            t[ii].join();
        }
    }
    
    return 0;
}


extern "C" void rEntry(double *dataPtr, const double *pIn) {
    atomic<bool> done;
    
    param_type pInSlice;
    for (size_t jj = 0; jj < pInSlice.size(); jj++) {
        pInSlice[jj] = pIn[jj];
    }
    
    calcErrorRef(Param(pInSlice),dataPtr, &done);
}








// Calculate phosphorylation at time points measured
int calcProfileSet (double *outData, double *tps, struct rates params, int nTps, double autocrine, double AXL, double GasStim) {
    ratesFull params2 = ratesFill(params);
    
    
    N_Vector state = N_VNew_Serial(Nspecies);
    if (check_flag((void *)state, (char*)"N_VNew_Serial", 0)) return(1);
    
    realtype t;
    
    N_Vector abstol = N_VNew_Serial(Nspecies);
    if (check_flag((void *)abstol, (char*)"N_VNew_Serial", 0)) return(1);
    
    void *cvode_mem = NULL;
    int flag;
    
    for (int ii = 0; ii < Nspecies; ii++) {
        Ith(abstol,ii) = abs_tol;
    }
    
    // Initialize state based on autocrine ligand
    flag = initState(state, params2, autocrine, AXL, abstol);
    if (check_flag(&flag, (char*)"Initializer", 1)) {
        N_VDestroy_Serial(abstol);
        N_VDestroy_Serial(state);
        return(1);
    }
    
    /* We've got the initial state, so now run through the kinetic data */

    
    Ith(state,0) += GasStim;
    t = 0;
    
    
    flag = solver_setup (&cvode_mem, state, &params2, abstol, SELECTED_MODEL);
    if (flag == 1) {
        cout << "Error at solver setup" << endl;
        N_VDestroy_Serial(abstol);
        N_VDestroy_Serial(state);
        return(1);
    }
    
    
    /* In loop, call CVode, print results, and test for error.
     Break out of loop when NOUT preset output times have been reached.  */
    size_t ii = 0;
    
    if (tps[0] == 0) {
        outData[0] = pYcalc(state,params);
        ii = 1;
    }
    
    for (; ii < nTps; ii++) {
        flag = CVode(cvode_mem, tps[ii], state, &t, CV_NORMAL);
        
        outData[ii] = pYcalc(state,params);
        
        if (check_flag(&flag, (char*)"CVode Time Course", 1)) {
            CVodeFree(&cvode_mem);
            N_VDestroy_Serial(abstol);
            N_VDestroy_Serial(state);
            return(1);
        }
    }
    
    /* Free integrator memory */
    CVodeFree(&cvode_mem);

    /* Free y and abstol vectors */
    N_VDestroy_Serial(abstol);
    N_VDestroy_Serial(state);
    
    return 0;
}

extern "C" int calcProfileMatlab(double *dataPtr, double *params, double *tps, int nTps, double autocrine, double AXL, double GasStim) {
    param_type pIn;
    
    for (size_t ii = 0; ii < pIn.size(); ii++)
        pIn[ii] = params[ii];

    int flag = calcProfileSet (dataPtr, tps, Param(pIn), nTps, autocrine, AXL, GasStim);
    
    return flag;
}

extern "C" int matlabDiffTPS(double *dataPtr, double AXLin, double *GasIn, int gridIn, double autocrine, double *params, double *tps, int nTps, double *dIn) {
    
    // Common
    realtype t = 0;
    void *cvode_mem = NULL;
    int flag;
    
    for (int ii = 0; ii < Nspecies; ii++)
        diffD[ii] = dIn[ii];
    
    // Create the parameter structure
    param_type pIn;
    struct rates pInS;
    for (size_t ii = 0; ii < pIn.size(); ii++) {
        pIn[ii] = params[ii];
    }
    pInS = Param(pIn);
    ratesFull pInS2 = ratesFill(pInS);
    // Done creating parameter structure
    
    // Get initial state
    N_Vector init_state = N_VNew_Serial(Nspecies);
    if (check_flag((void *)init_state, (char*)"N_VNew_Serial", 0)) return(1);
    N_Vector abstol = N_VNew_Serial(Nspecies);
    if (check_flag((void *)abstol, (char*)"N_VNew_Serial", 0)) return(1);
    
    
    for (int ii = 0; ii < Nspecies; ii++)
        Ith(abstol,ii) = abs_tol;
    
    // Initialize state based on autocrine ligand
    flag = initState(init_state, pInS2, autocrine, AXLin, abstol);
    if (check_flag(&flag, (char*)"Initializer", 1)) {
        N_VDestroy_Serial(abstol);
        N_VDestroy_Serial(init_state);
        return(1);
    }
    // Done getting initial state
    
    
    // Initialize full diffusion model
    N_Vector state = N_VNew_Serial(Nspecies * gridIn);
    if (check_flag((void *)state, (char*)"N_VNew_Serial", 0)) return(1);
    N_VDestroy_Serial(abstol);
    abstol = N_VNew_Serial(Nspecies * gridIn);
    if (check_flag((void *)abstol, (char*)"N_VNew_Serial", 0)) return(1);
    for (int ii = 0; ii < Nspecies*gridIn; ii++) {
        Ith(abstol,ii) = abs_tol;
    }
    
    for (size_t ii = 0; ii < gridIn; ii++) {
        for (size_t spec = 0; spec < Nspecies; spec++) {
            Ith(state,spec*((size_t) gridIn) + ii) = Ith(init_state,spec);
        }
    }
    
    for (size_t ii = 0; ii < gridIn; ii++) {
        Ith(state,ii) = GasIn[ii];
    }
    // Done initializing diffusion model
    
    
    flag = solver_setup (&cvode_mem, state, &pInS2, abstol, AXL_react_diff);
    if (flag == 1) {
        cout << "Error at solver setup" << endl;
        N_VDestroy_Serial(abstol);
        N_VDestroy_Serial(state);
        return(1);
    }
    
    size_t tIDX;
    
    if (tps[0] == 0) {
        for (size_t jj = 0; jj < NV_LENGTH_S(state); jj++) {
            dataPtr[jj] = Ith(state,jj);
            tIDX = 1;
        }
    } else {
        tIDX = 0;
    }
    
    for (; tIDX < nTps; tIDX++) {
        flag = CVode(cvode_mem, tps[tIDX], state, &t, CV_NORMAL);
        
        if (check_flag(&flag, (char*)"CVode", 1)) return(1);
        
        for (size_t jj = 0; jj < NV_LENGTH_S(state); jj++) {
            dataPtr[tIDX*((size_t) NV_LENGTH_S(state)) + jj] = Ith(state,jj);
        }
    }
    
    /* Free y and abstol vectors */
    N_VDestroy_Serial(state);
    N_VDestroy_Serial(abstol);
    
    /* Free integrator memory */
    CVodeFree(&cvode_mem);
    
    return 0;
}



//extern "C" int matlabFluxify(double *dataPtr, double *species, double *params) {
//    param_type pIn;
//    struct rates pInS;
//    for (size_t ii = 0; ii < pIn.size(); ii++) {
//        pIn[ii] = params[ii];
//    }
//    pInS = Param(pIn);
//    
//    fluxify(dataPtr, species, &pInS);
//    
//    return 0;
//}




extern "C" int matlabDiffTPS_pY(double *dataPtr, double AXLin, double *GasIn, int gridIn, double autocrine, double *params, double *tps, int nTps, double *dIn) {
    
    double dataPtrTemp[gridIn*nTps*Nspecies];
    
    int flag = matlabDiffTPS(dataPtrTemp, AXLin, GasIn, gridIn, autocrine, params, tps, nTps, dIn);
    if (flag == 1) return(1);
    
    // Create the parameter structure
    param_type pIn;
    struct rates pInS;
    for (size_t ii = 0; ii < pIn.size(); ii++) {
        pIn[ii] = params[ii];
    }
    pInS = Param(pIn);
    

    N_Vector state = N_VNew_Serial(Nspecies);
    if (check_flag((void *)state, (char*)"N_VNew_Serial", 0)) return(1);
    
    for (size_t time = 0; time < nTps; time++) {
        for (size_t gridP = 0; gridP < gridIn; gridP++) {
            for (size_t spec = 0; spec < Nspecies; spec++)
                Ith(state,spec) = dataPtrTemp[time*(gridIn*Nspecies) + spec*gridIn + gridP];
            
            dataPtr[time*gridIn + gridP] = pYcalc(state, pInS);
        }
    }
    
    
    return 0;
}

extern "C" int matlabDiffTPS_pYavg(double *dataPtr, double AXLin, double *GasIn, int gridIn, double autocrine, double *params, double *tps, int nTps, double *dIn) {
    
    double dataPtrTemp[gridIn*nTps];
    
    int flag = matlabDiffTPS_pY(dataPtrTemp, AXLin, GasIn, gridIn, autocrine, params, tps, nTps, dIn);
    if (flag == 1) return(1);
    
    double summ;
    
    for (size_t time = 0; time < nTps; time++) {
        summ = 0;
        
        for (size_t gridP = 0; gridP < gridIn; gridP++) {
            summ += dataPtrTemp[time*gridIn + gridP]/(gridIn)*(gridP);
        }
        
        dataPtr[time] = 2*summ/gridIn;
    }
    
    return 0;
}