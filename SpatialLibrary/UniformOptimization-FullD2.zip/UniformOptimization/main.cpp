
#include <nlopt.hpp>
#include <random>
#include <iostream>
#include <vector>
#include <thread>
#include <mutex>
#include <atomic>
#include <fstream>

#include "BlasHeader.h"
#include "Fitting.h"

using namespace nlopt;
using namespace std;

mutex mtx;
atomic<double> fBest;

double calcErrorOpt (unsigned n, const double *x, double *grad, void *data) {
    param_type inner;
    for (size_t ii = 0; ii < inner.size(); ii++) inner[ii] = x[ii];
    
    double error = calcError(Param(inner));
    
    return error;
}

double calcErrorOptLog (unsigned n, const double *x, double *grad, void *data) {
    ofstream errfile;
    param_type inner;
    for (size_t ii = 0; ii < inner.size(); ii++) inner[ii] = pow(10,x[ii]);
    
    double error = calcError(Param(inner));

    if (error < fBest) {
        fBest = error;
        
        mtx.lock();
        cout << fBest << endl;
        errfile.open ("output.log", ios::app);
        errfile << fBest << endl;
        errfile.close();
        mtx.unlock();
    }
    
    return error;
}

double calcErrorOpt (vector<double> x) {
    param_type inner;
    for (size_t ii = 0; ii < x.size(); ii++) inner[ii] = x[ii];
    return calcError(Param(inner));
}

double calcErrorOptLog (vector<double> x) {
    param_type inner;
    for (size_t ii = 0; ii < x.size(); ii++) inner[ii] = pow(10,x[ii]);
    return calcError(Param(inner));
}


void calcOptimizer(double seed) {
    double ff = 0;
    fBest = 1E10;
    vector<double> xx;
    
    vector<double> minn = {-9,-9,-5,-5,-5,-5,-5,-5,-5,-9,-9,-9,-9,-9,-9,-9,-9,-9,-9,-9,-9,-9,-9};
    vector<double> maxx = {3,3,5,5,5,5,5,5,5,5,5,5,5,1,1,1,1,1,1, 1,1,1,1};
    
    default_random_engine generator;
    generator.seed(seed);
    uniform_real_distribution<double> uniRnd(0,1);
    
    for (int ii = 0; ii < minn.size(); ii++) {
        xx.push_back(minn[ii] + (maxx[ii] - minn[ii]) * uniRnd(generator));
    }
    
    opt localOpt = opt(algorithm::LN_COBYLA, (unsigned int) minn.size());
    localOpt.set_lower_bounds(minn);
    localOpt.set_upper_bounds(maxx);
    localOpt.set_min_objective(calcErrorOptLog, nullptr);
    
    opt opter = opt(algorithm::G_MLSL, (unsigned int) minn.size());
    opter.set_lower_bounds(minn);
    opter.set_upper_bounds(maxx);
    opter.set_min_objective(calcErrorOptLog, nullptr);
    opter.set_local_optimizer(localOpt);
    
    int flag = opter.optimize(xx, ff);
    
    mtx.lock();
    cout << flag << ", " << ff << endl;
    mtx.unlock();
}

int main()
{
//    std::thread threads[8];
//    
//    for (int i=0; i<8; ++i)
//        threads[i] = std::thread(calcOptimizer,random());
//    
//    for (auto& th : threads) th.join();
    
    
    double params[] = {1.9, 0.00044296, 7.9629, 98, 0.031224, 50.478, 0.065396, 0.00012848, 3.58E-05, 0.022944, 0.2159, 1.04E-07, 2.10E-07, 0.0051401, 1.00E-09, 9.59E-08, 1.26E-07, 0.087601, 1.00E-06, 1.00E+00, 0.00011391, 0.19204};
    
    double tps[] = {10};
    double D[9] = {0, 0.01, 0, 0, 0, 0, 0, 0, 0};

    double GasIn[100];
    int gridIn = NELEMS(GasIn);
    double dataPtrs[NELEMS(tps)];

    double sigma = 1;
    double maxx = 0.1;
    double summ = 0;

    for (int ii = 0; ii < gridIn; ii++) {
        double x = ((double) ii) / ((double) gridIn);

        GasIn[ii] = cos(sigma*x) + 1;
        summ += GasIn[ii];
    }

    for (int ii = 0; ii < gridIn; ii++) {
        GasIn[ii] = GasIn[ii] / summ * maxx * gridIn;
        //cout << GasIn[ii] << endl;
    }

    matlabDiffTPS_pYavg(dataPtrs, 1000.0, GasIn, NELEMS(GasIn), 0.01, params, tps, NELEMS(tps), D);

    for (int ii = 0; ii < NELEMS(dataPtrs); ii++ ) {
        cout << dataPtrs[ii] << endl;
    }
    
    
    return 0;
}
