//
//  Fitting.cpp
//  UniformOptimization
//
//  Created by Aaron Meyer on 10/9/13.
//  Copyright (c) 2013 Aaron Meyer. All rights reserved.
//

#include "Fitting.h"
#include <vector>
#include <nlopt.hpp>
#include "HelperFunctions.h"
#include "CVodeHelpers.h"
#include <atomic>


using namespace std;
using namespace nlopt;



// Calculate phosphorylation at time points measured
int calcProfile (N_Vector outData, N_Vector outStim, struct rates params, int cellLine) {
    ratesFull params2 = ratesFill(params);
    
    
    N_Vector init_state = N_VNew_Serial(Nspecies);
    if (check_flag((void *)init_state, (char*)"N_VNew_Serial", 0)) return(1);
    N_Vector state = N_VNew_Serial(Nspecies);
    if (check_flag((void *)state, (char*)"N_VNew_Serial", 0)) return(1);
    
    realtype t;
    
    N_Vector abstol = N_VNew_Serial(Nspecies);
    if (check_flag((void *)abstol, (char*)"N_VNew_Serial", 0)) return(1);
    
    
    void *cvode_mem;
    int flag;
    
    cvode_mem = NULL;
    
    for (int ii = 0; ii < Nspecies; ii++) {
        Ith(abstol,ii) = abs_tol;
    }
    
    // Initialize state based on autocrine ligand
    flag = initState(init_state, params2, params.autocrine[cellLine], AXLL[cellLine], abstol);
    if (check_flag(&flag, (char*)"Initializer", 1)) {
        N_VDestroy_Serial(abstol);
        N_VDestroy_Serial(state);
        N_VDestroy_Serial(init_state);
        return(1);
    }
    
    /* We've got the initial state, so now run through the kinetic data */
    for (unsigned int stimuli = 0; stimuli < NELEMS(Gass); stimuli++) {
        
        for (int xx = 0; xx < Nspecies; xx++) {
            Ith(state,xx) = Ith(init_state,xx);
        }
        
        Ith(state,0) += Gass[stimuli];
        t = 0;
        
        flag = solver_setup (&cvode_mem, state, &params2, abstol, SELECTED_MODEL);
        if (flag == 1) {
            cout << "Error at solver setup" << endl;
            N_VDestroy_Serial(abstol);
            N_VDestroy_Serial(state);
            N_VDestroy_Serial(init_state);
            return(1);
        }
        
        /* In loop, call CVode, print results, and test for error.
         Break out of loop when NOUT preset output times have been reached.  */
        
        Ith(outData,stimuli*NELEMS(times)) = pYcalc(state,params);
        
        
        for (unsigned int ii = 1; ii < NELEMS(times); ii++) {
            flag = CVode(cvode_mem, times[ii], state, &t, CV_NORMAL);
            
            Ith(outData,stimuli*NELEMS(times) + ii) = pYcalc(state,params);
            
            
            if (check_flag(&flag, (char*)"CVode Time Course", 1)) {
                CVodeFree(&cvode_mem);
                N_VDestroy_Serial(abstol);
                N_VDestroy_Serial(state);
                N_VDestroy_Serial(init_state);
                return(1);
            }
        }
        
        /* Free integrator memory */
        CVodeFree(&cvode_mem);
    }
    
    /* We've got the initial state, so now run through the dose data */
    for (unsigned int stimuli = 0; stimuli < NELEMS(GassDose); stimuli++) {
        // Load the initial state (t = 0)
        for (int xx = 0; xx < Nspecies; xx++) {
            Ith(state,xx) = Ith(init_state,xx);
        }
        
        Ith(state,0) += GassDose[stimuli];
        t = 0;
        
        flag = solver_setup (&cvode_mem, state, &params2, abstol, SELECTED_MODEL);
        if (flag == 1) {
            cout << "Error at solver setup" << endl;
            N_VDestroy_Serial(abstol);
            N_VDestroy_Serial(state);
            N_VDestroy_Serial(init_state);
            return(1);
        }
        
        flag = CVode(cvode_mem, DoseTime, state, &t, CV_NORMAL);
        if (check_flag(&flag, (char*)"CVode Dose Response", 1)) {
            CVodeFree(&cvode_mem);
            N_VDestroy_Serial(abstol);
            N_VDestroy_Serial(state);
            N_VDestroy_Serial(init_state);
            return(1);
        }
        
        Ith(outStim,stimuli) = pYcalc(state,params);
        
        /* Free integrator memory */
        CVodeFree(&cvode_mem);
    }
    
    /* Free y and abstol vectors */
    N_VDestroy_Serial(abstol);
    N_VDestroy_Serial(state);
    N_VDestroy_Serial(init_state);
    
    return 0;
}




double errorOpt(unsigned n, const double *x, double *grad, void *data) {
    
    struct inData dataS;
    double xx = 0;
    
    memcpy(&dataS, data, sizeof(dataS));
    
    
    for (int ii = 0; ii < NV_LENGTH_S(dataS.fitt); ii++) {
        xx += pow((((double) Ith(dataS.fitt,ii) * x[0]) - dataS.pYmeas[ii]) / dataS.errorMeas[ii], 2);
    }
    
    return xx;
}

void errorOptPrint(vector<double> x, void *data) {
    
    struct inData dataS;
    double xx = 0;
    
    memcpy(&dataS, data, sizeof(dataS));
    
    
    for (int ii = 0; ii < NV_LENGTH_S(dataS.fitt); ii++) {
        xx += pow((((double) Ith(dataS.fitt,ii) * x[0]) - dataS.pYmeas[ii]) / dataS.errorMeas[ii], 2);
        
        
        cout << pow((((double) Ith(dataS.fitt,ii) * x[0]) - dataS.pYmeas[ii]) / dataS.errorMeas[ii], 2) << "\t\t" <<
        ((double) Ith(dataS.fitt,ii) * x[0]) << "\t" << dataS.pYmeas[ii] << "\t" << dataS.errorMeas[ii] << endl;
    }
    
    
}

double errorFuncOpt (N_Vector fitt, const double *pYmeas, const double *errorMeas, int print) {
    struct inData dataS;
    dataS.fitt = fitt;
    dataS.pYmeas = pYmeas;
    int flag = 0;
    dataS.errorMeas = errorMeas;
    
    double ff = 0;
    vector<double> xx = {100};
    
    opt opter = opt(algorithm::LN_COBYLA, 1);
    
    
    opter.set_lower_bounds(0);
    opter.set_upper_bounds(1E8);
    opter.set_min_objective(errorOpt,&dataS);
    opter.set_xtol_rel(1E-5);
    
    
    flag = opter.optimize(xx, ff);
    
    
    if (flag < 0) {
        return 1E6;
    };
    
    if (print == 1) {
        errorOptPrint(xx, &dataS);
        cout << "Opt: " << xx[0] << endl;
    }
    
    
    return ff;
}


double calcError (struct rates params) {
    
    N_Vector outData = N_VNew_Serial(NELEMS(Gass)*NELEMS(times));
    N_Vector outStim = N_VNew_Serial(NELEMS(GassDose));
    N_Vector outDataAll = N_VNew_Serial(NELEMS(Gass)*NELEMS(times)*NELEMS(AXLL));
    
    double error = 0;
    int flag;
    
    
    for (unsigned short ii = 0; ii < NELEMS(AXLL); ii++) {
        if (ii == 1) continue;
        
        flag = calcProfile (outData, outStim, params, ii);
        
        if (flag != 0) {
            N_VDestroy_Serial(outData);
            N_VDestroy_Serial(outStim);
            N_VDestroy_Serial(outDataAll);
            return 1000000;
        }
        
        error += errorFuncOpt (outData, &pY[ii*NELEMS(Gass)*NELEMS(times)], &pYerror[ii*NELEMS(Gass)*NELEMS(times)], 0);
        error += errorFuncOpt (outStim, pYdose[ii], DoseError[ii], 0);
    }
    
    N_VDestroy_Serial(outData);
    N_VDestroy_Serial(outStim);
    N_VDestroy_Serial(outDataAll);
    
    return error;
}



double errorFunc (double fitt, double pYmeas, double errorMeas) {
    return pow((((double)fitt) - pYmeas) / errorMeas, 2);
}


void calcErrorRef (struct rates params, double *out, atomic<bool> *done) {
    *out = calcError(params);
    *done = true;
}

