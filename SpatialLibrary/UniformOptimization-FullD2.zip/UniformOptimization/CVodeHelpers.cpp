//
//  CVodeHelpers.cpp
//  UniformOptimization
//
//  Created by Aaron Meyer on 10/8/13.
//  Copyright (c) 2013 Aaron Meyer. All rights reserved.
//


#include <cvode/cvode.h>             /* prototypes for CVODE fcts., consts. */
#include <cvode/cvode_dense.h>       /* prototype for CVDense */
#include <sundials/sundials_dense.h> /* definitions DlsMat DENSE_ELEM */
#include <sundials/sundials_types.h> /* definition of type realtype */
#include <cvode/cvode_lapack.h>
#include <iostream>
#include <fstream>
#include <cvode/cvode_diag.h>

using namespace std;


#include "CVodeHelpers.h"
#include "HelperFunctions.h"



/*
 * Check function return value...
 *   opt == 0 means SUNDIALS function allocates memory so check if
 *            returned NULL pointer
 *   opt == 1 means SUNDIALS function returns a flag so check if
 *            flag >= 0
 *   opt == 2 means function allocates memory so check if returned
 *            NULL pointer
 */
int check_flag(void *flagvalue, char *funcname, int opt) {
    ofstream errfile;
    
    int *errflag;
    
    /* Check if SUNDIALS function returned NULL pointer - no memory allocated */
    if (opt == 0 && flagvalue == NULL) {
        
        if (print_CV_err == 1) {
            cout << "SUNDIALS_ERROR: " << funcname << "() failed - returned NULL pointer" << endl;
        } else if (print_CV_err == 2) {
            errfile.open ("error.txt", ios::app);
            errfile << "SUNDIALS_ERROR: " << funcname << "() failed - returned NULL pointer" << endl;
            errfile.close();
        }
        return(1); }
    
    /* Check if flag < 0 */
    else if (opt == 1) {
        errflag = (int *) flagvalue;
        if (*errflag < 0) {
            if (print_CV_err == 1) {
                cout << "SUNDIALS_ERROR: " << funcname << "() failed with flag = " << *errflag << endl;
            } else if (print_CV_err == 2) {
                errfile.open ("error.txt", ios::app);
                errfile << "SUNDIALS_ERROR: " << funcname << "() failed with flag = " << *errflag << endl;
                errfile.close();
            }
            return(1);
        }
    }
    
    /* Check if function returned NULL pointer - no memory allocated */
    else if (opt == 2 && flagvalue == NULL) {
        if (print_CV_err == 1) {
            cout << "MEMORY_ERROR: " << funcname << "() failed - returned NULL pointer" << endl;
        } else if (print_CV_err == 2) {
            errfile.open ("error.txt", ios::app);
            errfile << "MEMORY_ERROR: " << funcname << "() failed - returned NULL pointer" << endl;
            errfile.close();
        }
        return(1); }
    
    return(0);
}






//Get and print some final statistics
void PrintFinalStats(void *cvode_mem) {
    long int nst, nfe, nsetups, nje, nfeLS, nni, ncfn, netf, nge;
    int flag;

    flag = CVodeGetNumSteps(cvode_mem, &nst);
    check_flag(&flag, (char*)"CVodeGetNumSteps", 1);
    flag = CVodeGetNumRhsEvals(cvode_mem, &nfe);
    check_flag(&flag, (char*)"CVodeGetNumRhsEvals", 1);
    flag = CVodeGetNumLinSolvSetups(cvode_mem, &nsetups);
    check_flag(&flag, (char*)"CVodeGetNumLinSolvSetups", 1);
    flag = CVodeGetNumErrTestFails(cvode_mem, &netf);
    check_flag(&flag, (char*)"CVodeGetNumErrTestFails", 1);
    flag = CVodeGetNumNonlinSolvIters(cvode_mem, &nni);
    check_flag(&flag, (char*)"CVodeGetNumNonlinSolvIters", 1);
    flag = CVodeGetNumNonlinSolvConvFails(cvode_mem, &ncfn);
    check_flag(&flag, (char*)"CVodeGetNumNonlinSolvConvFails", 1);

    flag = CVDlsGetNumJacEvals(cvode_mem, &nje);
    check_flag(&flag, (char*)"CVDlsGetNumJacEvals", 1);
    flag = CVDlsGetNumRhsEvals(cvode_mem, &nfeLS);
    check_flag(&flag, (char*)"CVDlsGetNumRhsEvals", 1);

    flag = CVodeGetNumGEvals(cvode_mem, &nge);
    check_flag(&flag, (char*)"CVodeGetNumGEvals", 1);

    printf("\nFinal Statistics:\n");
    printf("nst = %-6ld nfe  = %-6ld nsetups = %-6ld nfeLS = %-6ld nje = %ld\n",
           nst, nfe, nsetups, nfeLS, nje);
    printf("nni = %-6ld ncfn = %-6ld netf = %-6ld nge = %ld\n \n",
           nni, ncfn, netf, nge);
}



void errorHandler (int error_code, const char *module, const char *function, char *msg, void *eh_data) {
    ofstream errfile;
    
    if (print_CV_err == 1) {
        cout << msg << endl;
    } else if (print_CV_err == 2) {
        errfile.open ("error.txt", ios::app);
        errfile << msg << endl;
        errfile.close();
    }
    
}


int solver_setup (void **cvode_mem, N_Vector init, void *params, N_Vector abstol, CVRhsFn f) {

    int flag;
    
    /* Call CVodeCreate to create the solver memory and specify the
     * Backward Differentiation Formula and the use of a Newton iteration */
    *cvode_mem = CVodeCreate(CV_BDF, CV_NEWTON);
    if (check_flag((void *)cvode_mem, (char*)"CVodeCreate", 0)) {
        CVodeFree(cvode_mem);
        return(1);
    }
    
    CVodeSetErrHandlerFn(*cvode_mem, &errorHandler, nullptr);
    
    /* Call CVodeInit to initialize the integrator memory and specify the
     * user's right hand side function in y'=f(t,y), the inital time T0, and
     * the initial dependent variable vector y. */
    flag = CVodeInit(*cvode_mem, f, 0.0, init);
    if (check_flag(&flag, (char*)"CVodeInit", 1)) {
        CVodeFree(cvode_mem);
        return(1);
    }
    
    // Pass along the parameter structure to the differential equations
    flag = CVodeSetUserData(*cvode_mem, params);
    
    /* Call CVodeSVtolerances to specify the scalar relative tolerance
     * and vector absolute tolerances */
    flag = CVodeSVtolerances(*cvode_mem, rel_tol, abstol);
    if (check_flag(&flag, (char*)"CVodeSVtolerances", 1)) {
        CVodeFree(cvode_mem);
        return(1);
    }
    
    /* Call CVDense to specify the CVDENSE dense linear solver */
    
    if (NV_LENGTH_S(init) > 20) {
        flag = CVLapackDense(*cvode_mem, (int) NV_LENGTH_S(init));
    } else {
        flag = CVDense(*cvode_mem, NV_LENGTH_S(init));
    }
    if (check_flag(&flag, (char*)"CVDense", 1)) {
        CVodeFree(cvode_mem);
        return(1);
    }
    
    /*if (NV_LENGTH_S(init) == Nspecies) {
        flag = CVDlsSetDenseJacFn(*cvode_mem, &AXL_react_Jac);
        if (check_flag(&flag, (char*)"CVDlsSetDenseJacFn", 1)) {
            CVodeFree(cvode_mem);
            return(1);
        }
    }*/
    
    
    CVodeSetMaxNumSteps(*cvode_mem, 2E6);
    CVodeSetMinStep(*cvode_mem,0);
    CVodeSetMaxStep(*cvode_mem,1000);
    
    return 0;
}